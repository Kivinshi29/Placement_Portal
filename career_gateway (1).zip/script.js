function showSection(id, el) {
  document.querySelectorAll('.section').forEach(sec => sec.classList.remove('active'));
  document.querySelectorAll('.sidebar ul li').forEach(li => li.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  el.classList.add('active');
}

function goToAcademic() {
  const fileInput = document.getElementById('resumeFile');
  if (!fileInput.files.length) {
    alert('Please select a resume file.');
    return;
  }
  showSection('academic', document.querySelectorAll('.sidebar ul li')[1]);
}

function submitStudent(e) {
  e.preventDefault();
  const file = document.getElementById("resumeFile").files[0];
  const fileUrl = URL.createObjectURL(file);
  const student = {
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    phone: document.getElementById("phone").value,
    location: document.getElementById("location").value,
    linkedin: document.getElementById("linkedin").value,
    github: document.getElementById("github").value,
    skills: document.getElementById("skills").value,
    enroll: document.getElementById("enroll").value,
    branch: document.getElementById("branch").value,
    semester: document.getElementById("semester").value,
    cgpa: document.getElementById("cgpa").value,
    backlogs: document.getElementById("backlogs").value,
    achievements: document.getElementById("achievements").value,
    resumeUrl: fileUrl
  };
  const allStudents = JSON.parse(localStorage.getItem("students") || "[]");
  allStudents.push(student);
  localStorage.setItem("students", JSON.stringify(allStudents));
  alert("✔️ Registration successful!");
  e.target.reset();
  document.getElementById("resumeFile").value = "";
  showSection('profile', document.querySelectorAll('.sidebar ul li')[0]);
}

document.querySelector(".logout").addEventListener("click", function(e) {
  e.preventDefault();
  localStorage.clear();
  alert("Logged out successfully!");
  location.reload();
});